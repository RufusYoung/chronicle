# RF6 Sep24 Remediation Evidence

Runtime/export source: 273678ee3a8dd287d3eee01bf889a808b0e3c307. Internal candidate, not a passed human first experience.

- `regular_initial/`: first full regular attempt146/148, retained failures. `regular_final/`: full148/148. A final elapsed-time receipt correction followed the journey test within this run; `focused_final/` reruns that affected contract and renderer.
- `render_initial/`: first actual renderer33/34. `render_final/`: full34/34 after preserving the old incident profile in its regression. Program-driven rendering is not human play.
- `package_parity/`: three scripted legal public-action policies, exact source/package native truth across bootstrap, definitions, Stores, session, time, RNG and log. Seed81001 risky find fails;89037 cave uses real rope;81001 night uses physical host/stock/payment. No injected world state or dice.
- `legal_play_81001/` and `legal_play_89037/`: source native checkpoints and full legal-script transcripts. The night checkpoint forks drink vs bed; separate bounded passive followup waits for returned rope to enter ordinary NPC work. Passive time is not a core-play duration claim.
- `journey_surface/`: actual720/900/1080 pictures of choices, result, map and static cave/guesthouse illustrations. `danger_surface/`: actual combat UI. `user_native_render/`: read-only rendering of supplied263h native save with exact-world checks. It is a current rendering, NOT an immutable before screenshot.
- `package_user_save.json`: actual package loads the user's Godot4.5 native world; source file never modified. `package_startup.json`: new and168h frames on this development computer. `build_manifest.json`: clean source and hashes of executable/PCK.
- `verification_summary.json`: aggregate observations from completed tool runs. Source23/23 protocol98.666s and package23/23 protocol71.161s were observed in terminal tool output; full raw unittest output was not separately retained here. This summary is not fabricated raw logs.
- `journey45.log`/`.err`: source contract35/35 under4.5 before the elapsed-time receipt-only correction. Not a universal bidirectional4.5/4.6 save guarantee.

Excluded deliberately: user original save and its private backup, raw APK, extracted commercial text/images/code, UnityPy environment, generated-image cache, executable/PCK (available separately in builds/h1-windows). The archive contains original Chronicle evidence only. ZIP presence/test totals do not prove enjoyment, measured15-25minute human play, RF6 completion or a submission-ready demo.
