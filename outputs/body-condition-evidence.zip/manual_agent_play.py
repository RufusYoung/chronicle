"""Interactive developer AI play using public protocol only; not human UI play."""

import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "chronicle-godot/tools"))
from agent_play import ChronicleClient

sys.stdin.reconfigure(encoding="utf-8")
sys.stdout.reconfigure(encoding="utf-8")
with (Path(__file__).parent / "developer_play.jsonl").open("x", encoding="utf-8") as log:
    with ChronicleClient(packaged=True) as game:
        print("READY: public commands only; quit closes the isolated process", flush=True)
        for line in sys.stdin:
            request = json.loads(line)
            if request["command"] == "quit":
                break
            arguments = dict(request)
            command = arguments.pop("command")
            began = time.time()
            response = game.request(command, **arguments)
            log.write(json.dumps({"requested_at": began, "request": request, "response": response}, ensure_ascii=False) + "\n")
            log.flush()
            observation = response.get("observation", {})
            public = {key: observation.get(key) for key in (
                "time", "player", "location", "feedback", "decision", "visible_people",
                "visible_observations", "agency", "player_life_followups") if key in observation}
            print(json.dumps({"ok": response.get("ok"), "error": response.get("error"),
                              "observation": public, "choices": response.get("choices", [])}, ensure_ascii=False), flush=True)
