"""Read-only audit of the scoped interruption fix and the packaged executable."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "chronicle-godot/tools"))
from verify_local_life import read, truth

evidence = Path(__file__).parent
package = ROOT / "builds/h1-windows"
checks = {}
for name in ("source", "package"):
    log = (evidence / f"{name}_protocol.log").read_text(encoding="utf-8-sig")
    checks[name + "_protocol"] = "Ran 19 tests" in log and log.rstrip().endswith("OK")
    checks[name + "_replay"] = read(evidence / f"{name}_replay.json")["passed"]
checks["source_package_truth"] = truth(read(evidence / "source.native.json")) == truth(read(evidence / "package.native.json"))
checks["natural_route"] = not any(f.get("fact_type") == "test_injection" for f in read(evidence / "source.native.json")["stores"]["facts"])
for folder, expected in (("player_regression", 8), ("body_regression", 1), ("provisions_regression", 1), ("interruption", 2), ("interruption_final", 1)):
    rows = read(evidence / folder / "results.json")
    rows = [rows] if isinstance(rows, dict) else rows
    checks[folder] = len(rows) == expected and all(r["Passed"] for r in rows)
manifest = read(package / "build_manifest.json")
checks["clean_export"] = manifest["sourceDirty"] is False
checks["manifest_identity"] = manifest == read(evidence / "package_build_manifest.json")
checks["package_hashes"] = all(hashlib.sha256((package / row["name"]).read_bytes()).hexdigest().upper() == row["sha256"] for row in manifest["files"])
paths = ["chronicle-godot/scripts", "chronicle-godot/data", "chronicle-godot/scenes"]
checks["runtime_matches_export"] = subprocess.run(["git", "diff", "--quiet", manifest["sourceCommit"], "--", *paths], cwd=ROOT).returncode == 0
changed = subprocess.check_output(["git", "diff", "--name-only", "a53caeb", manifest["sourceCommit"], "--", *paths], cwd=ROOT, text=True).splitlines()
checks["scoped_runtime_change"] = changed == ["chronicle-godot/scripts/sim/player/player_life.gd"]
for name in ("body_week", "old_provisions_week", "legacy_day30", "startup"):
    checks["package_" + name] = read(evidence / f"package_{name}.json")["passed"]
report = {"passed": all(checks.values()), "checks": checks, "source_commit": manifest["sourceCommit"],
          "boundary": "Scoped follow-on to body integration. Source renderer, package protocol/replay and native startup checks; not human play or a full 167-test rerun. External --script rendering is unsupported by this release and excluded."}
(evidence / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(f"PLAY_FEEDBACK_AUDIT {sum(checks.values())}/{len(checks)}")
for key, passed in checks.items():
    if not passed:
        print("FAIL", key)
raise SystemExit(0 if report["passed"] else 1)
