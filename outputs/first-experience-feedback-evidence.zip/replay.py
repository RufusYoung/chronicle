"""Replay the recorded public AI choices; compare native truth only afterwards."""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "chronicle-godot/tools"))
from agent_play import ChronicleClient
from verify_local_life import read, truth

parser = argparse.ArgumentParser()
parser.add_argument("--packaged", action="store_true")
args = parser.parse_args()
prefix = "package" if args.packaged else "source"
records = [json.loads(line) for line in (ROOT / "work/body-condition/developer_play.jsonl").read_text(encoding="utf-8").splitlines()]
rows = []
checks = {}
with ChronicleClient(packaged=args.packaged) as game:
    response = {}
    for record in records:
        request = dict(record["request"])
        command = request.pop("command")
        if command == "save":
            continue
        if command not in {"start", "act"}:
            raise ValueError("Only a start followed by public choices is supported")
        if command == "act":
            assert any(c["enabled"] and c["choice_id"] == request["choice_id"] for c in response["choices"])
        response = game.request(command, **request)
        assert response["ok"], response
        rows.append(response)
        if request.get("choice_id", "").startswith("player_life/help:"):
            feedback = response["observation"]["feedback"]
            checks["specific_interruption"] = feedback["status"] == "interrupted" and "陶苇已离开现场" in feedback["body"] and "2/4" in feedback["body"]
    slot = f"work_receipt_{prefix}_{os.getpid()}"
    assert game.request("save", slot=slot)["ok"]
    assert game.request("load", slot=slot)["observation"] == response["observation"]
native = Path(os.environ["APPDATA"]) / "Godot/app_userdata/CHRONICLE_GODOT/agent_play/play/echo_realm" / (slot + ".json")
before = truth(read(ROOT / "work/body-condition/developer_play.native.json"))
after = truth(read(native))
checks.update({"truth:" + key: after[key] == before[key] for key in before})
output = Path(__file__).parent
(output / (prefix + ".native.json")).write_bytes(native.read_bytes())
(output / (prefix + ".transcript.json")).write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
(output / (prefix + "_replay.json")).write_text(json.dumps({"passed": all(checks.values()), "checks": checks, "scope": "Recorded legal choices replay; not a new independent playtest."}, indent=2), encoding="utf-8")
print(prefix, checks)
raise SystemExit(0 if all(checks.values()) else 1)
